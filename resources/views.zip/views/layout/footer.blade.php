<footer>
    <div class="row">
        <div class="large-3 medium-6 columns">
            <div class="widgetBox">
                <div class="widgetTitle">
                    <h5>About Betube</h5>
                </div>
                <div class="textwidget">
                    Betube video wordpress theme lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s book.
                </div>
            </div>
        </div>
        
        <div class="large-3 medium-6 columns">
            <div class="widgetBox">
                <div class="widgetTitle">
                    <h5>Tags</h5>
                </div>
                <div class="tagcloud">
                    <a href="#">3D Videos</a>
                    <a href="#">Videos</a>
                    <a href="#">HD</a>
                    <a href="#">Movies</a>
                    <a href="#">Sports</a>
                    <a href="#">3D</a>
                    <a href="#">Movies</a>
                    <a href="#">Animation</a>
                    <a href="#">HD</a>
                    <a href="#">Music</a>
                    <a href="#">Recreation</a>
                </div>
            </div>
        </div>
        <div class="large-3 medium-6 columns">
            <div class="widgetBox">
                <div class="widgetTitle">
                    <h5>Subscribe Now</h5>
                </div>
                <div class="widgetContent">
                    <form data-abide novalidate method="post">
                        <p>Subscribe to get exclusive videos</p>
                        <div class="input">
                            <input type="text" placeholder="Enter your full Name" required>
                            <span class="form-error">
                                Yo, you had better fill this out, it's required.
                            </span>
                        </div>
                        <div class="input">
                            <input type="email" id="email" placeholder="Enter your email addres" required>
                            <span class="form-error">
                              I'm required!
                            </span>
                        </div>
                        <button class="button" type="submit" value="Submit">Sign up Now</button>
                    </form>
                    
                    <div class="social-links">
                        <h5>We’re a Social Bunch</h5>
                        <div class="float-right easy-share" data-easyshare data-easyshare-http data-easyshare-url="http://vdopedia.com">
                                        <!-- Total -->
                                        

                                        <!-- Facebook -->
                                        <button class="secondary-button" data-easyshare-button="facebook" data-toggle="tooltip" data-placement="top" title="share on facebook" data-easyshare-tweet-text="" style="padding-right: 10px;">
                                            <i   class="fa fa-facebook"></i>
                                           
                                        </button>
                                        {{-- <span data-easyshare-button-count="facebook"></span> --}}

                                        <!-- Twitter -->
                                        <button class="secondary-button" data-easyshare-button="twitter" data-toggle="tooltip" data-placement="top" title="share on twitter" data-easyshare-tweet-text="" style="padding-right: 10px;">
                                            <i  class="fa fa-twitter"></i>
                                           
                                        </button>
                                         <button class="secondary-button" data-easyshare-button="linkedin" data-toggle="tooltip" data-placement="top" title="share on linkedin" data-easyshare-tweet-text="" style="padding-right: 10px;">
                                            <i   class="fa fa-linkedin"></i>
                                           
                                        </button>
                                        {{-- <button class="secondary-button" data-easyshare-button="flickr" data-toggle="tooltip" data-placement="top" title="share on flickr" data-easyshare-tweet-text="" style="padding-right: 10px;">
                                            <i   class="fa fa-flickr"></i>
                                           
                                        </button> --}}
                                        {{-- <span data-easyshare-button-count="twitter"></span> --}}

                                        <!-- Google+ -->
                                        <button  class="secondary-button" data-easyshare-button="google" >
                                            <i data-toggle="tooltip" data-placement="top" title="share on google plus" class="fa fa-google-plus"></i>
                                            
                                        </button>
                                        
 
                                        
                                        {{-- <span data-easyshare-button-count="google"></span> --}}

                                        {{-- <div data-easyshare-loader>Loading...</div> --}}
                                    </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <a href="#" id="back-to-top" title="Back to top"><i class="fa fa-angle-double-up"></i></a>
</footer><!-- footer -->